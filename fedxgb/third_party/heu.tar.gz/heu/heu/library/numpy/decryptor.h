// Copyright 2022 Ant Group Co., Ltd.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <utility>

#include "heu/library/numpy/matrix.h"
#include "heu/library/phe/phe.h"

namespace heu::lib::numpy {

class Decryptor : public phe::Decryptor {
 public:
  explicit Decryptor(phe::Decryptor decryptor)
      : phe::Decryptor(std::move(decryptor)) {}

  using phe::Decryptor::Decrypt;
  PMatrix Decrypt(const CMatrix& in) const;

  // Decrypt ct and make sure pt is in range (-2^range_bits, 2^range_bits)
  // throws an exception if plaintext is out of range.
  // Range checking is used to block OU plaintext overflow attack, see HEU
  // documentation for details
  using phe::Decryptor::DecryptInRange;
  PMatrix DecryptInRange(const CMatrix& in, size_t range_bits = 128) const;
};

}  // namespace heu::lib::numpy

# Python Paillier Benchmark

doc:
https://python-paillier.readthedocs.io/en/develop/index.html

github:
https://github.com/data61/python-paillier

Please make sure python package 'gmpy2' is installed.


```shell
# pip install -r requirements.txt
python python_paillier_bench.py
```
